package com.EduLink.OnlineQuiz.controller;

import com.EduLink.OnlineQuiz.data.Quiz;
import com.EduLink.OnlineQuiz.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/quiz")
public class QuizController
{
    @Autowired
    private QuizService quizService;

    @GetMapping(path = "/all")
    public List<Quiz> getAllQuizzes()
    {
        return quizService.getAllQuiz();
    }
}
