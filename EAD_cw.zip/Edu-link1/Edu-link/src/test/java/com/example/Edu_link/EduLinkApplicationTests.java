package com.example.Edu_link;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduLinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
