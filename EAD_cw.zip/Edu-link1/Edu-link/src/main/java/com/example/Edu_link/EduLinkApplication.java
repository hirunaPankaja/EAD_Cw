package com.example.Edu_link;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduLinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduLinkApplication.class, args);
	}

}
