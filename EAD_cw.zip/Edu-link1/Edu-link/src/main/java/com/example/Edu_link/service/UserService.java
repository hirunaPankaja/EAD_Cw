package com.example.Edu_link.service;

import com.example.Edu_link.model.User;
import com.example.Edu_link.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository)
    {
        this.userRepository = userRepository;
    }

    public User createUser(User user) {
        // Check for existing user by email
        if (userRepository.findByEmail(user.getEmail()) != null)
        {
            System.out.println("Error creating user: User with email " + user.getEmail() + " already exists.");
            throw new RuntimeException("User with email " + user.getEmail() + " already exists.");
        }
        try
        {
            return userRepository.save(user);
        }
        catch (Exception e)
        {
            System.out.println("Error creating user: " + e.getMessage());
            throw new RuntimeException("Error creating user", e);
        }
    }

    public User saveUser(User user) {
        return userRepository.save(user);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserByEmail(String email) {
        return Optional.ofNullable(userRepository.findByEmail(email));
    }
}
