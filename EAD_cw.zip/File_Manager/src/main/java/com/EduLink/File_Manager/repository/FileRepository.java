package com.EduLink.File_Manager.repository;

import com.EduLink.File_Manager.data.FileData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FileRepository extends JpaRepository<FileData, Long> {
    List<FileData> findByLessonName(String lessonName);
}
