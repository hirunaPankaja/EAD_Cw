package com.EduLink.File_Manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
