package com.EduLink.Authentication.data;

public interface UserRepository {
}
