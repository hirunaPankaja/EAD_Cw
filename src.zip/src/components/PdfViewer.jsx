// src/Components/PdfViewer.jsx
import React, { useEffect, useState } from 'react';
import { Document, Page } from 'react-pdf'; // Import Page component
import axios from 'axios';
import './PdfViewer.css';

const PdfViewer = () => {
    const [file, setFile] = useState(null);
    const urlParams = new URLSearchParams(window.location.search);
    const fileName = urlParams.get('name') || 'default.pdf'; // Default file name

    useEffect(() => {
        const fetchFile = async () => {
            try {
                const response = await axios.get(`http://localhost:8082/files/search?name=${fileName}`, {
                    responseType: 'json',
                });

                if (response.data.length > 0) {
                    const fileId = response.data[0].id; // Just pick the first result for simplicity
                    const fileResponse = await axios.get(`http://localhost:8082/files/${fileId}`, {
                        responseType: 'blob',
                    });
                    setFile(URL.createObjectURL(fileResponse.data));
                }
            } catch (error) {
                console.error('Error fetching file:', error);
            }
        };
        fetchFile();
    }, [fileName]);

    return (
        <div className="pdf-viewer">
            {file ? (
                <Document file={file}>
                    <Page pageNumber={1} />
                </Document>
            ) : (
                <p>Loading...</p>
            )}
        </div>
    );
};

export default PdfViewer;
