import React from 'react';
import './OlSubjectDashboard.css';
import { FaFlask, FaAtom, FaCalculator } from 'react-icons/fa';
import SubjectCard from "../components/SubjectCard";
import Footer from "../components/Footer.jsx";
import Navbar from "../components/Navbar.jsx";

const subjects =[
    {name: 'Science', details:'Quiz, All Papers,Notes' ,icon:<FaFlask/>,color:'blue' }

];
function OlSubjectDashboard() {
    return (
        <div className="container">
            <Navbar/>
            <div className="subjects">
                {subjects.map((subject, index) => (
                    <SubjectCard key={index} subject={subject} />
                ))}
            </div>
            <div className="footer">
                <Footer />
            </div>
        </div>
    )
}
export default OlSubjectDashboard;