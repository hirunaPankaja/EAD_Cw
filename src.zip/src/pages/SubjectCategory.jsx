import React, { useEffect, useState } from 'react';
import './SubjectCategory.css';
import { FaQuestionCircle, FaStickyNote } from "react-icons/fa";
import SubjectCard from "../components/SubjectCard.jsx";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";

const subjects = [
    { name: 'Quiz', details: 'Quiz for Subject ', icon: <FaQuestionCircle />, color: 'green' },
    { name: 'Notes', details: 'Notes', icon: <FaStickyNote />, color: 'brown' },
];

function SubjectCategory() {
    const [timePercentage, setTimePercentage] = useState(0);
    const [correctionPercentage, setCorrectionPercentage] = useState(0);
    const [overallPercentage, setOverallPercentage] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setTimePercentage(prev => (prev < 50 ? prev + 1 : 50));
            setCorrectionPercentage(prev => (prev < 70 ? prev + 1 : 70));
            setOverallPercentage(prev => (prev < 85 ? prev + 1 : 85));
        }, 30);

        // Cleanup interval on component unmount
        return () => clearInterval(interval);
    }, []);

    const calculateStrokeDashoffset = (percentage) => {
        const radius = 70;
        const circumference = 2 * Math.PI * radius;
        return circumference * (1 - percentage / 100);
    };

    const handleSubjectClick = (subject) => {
        // Define what happens when a subject card is clicked
        console.log(subject);
    };

    return (
        <>
            <Navbar />
            <div className="container">
                <div className="subject-details">
                    <h2>Subject Details</h2>
                    {/* Display subject details here */}
                </div>
                <div className="subjects">
                    {subjects.map((subject, index) => (
                        <SubjectCard
                            key={index}
                            subject={subject}
                            onClick={() => handleSubjectClick(subject)}
                        />
                    ))}
                </div>
                <div className="metrics">
                    <div className="circle-container">
                        <div className="circle">
                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="160px" height="160px">
                                <defs>
                                    <linearGradient id="GradientColor1">
                                        <stop offset="0%" stopColor="#e91e63"/>
                                        <stop offset="100%" stopColor="#673ab7"/>
                                    </linearGradient>
                                </defs>
                                <circle cx="80" cy="80" r="70" fill="none" stroke="#e0e0e0" strokeWidth="20"/>
                                <circle
                                    cx="80"
                                    cy="80"
                                    r="70"
                                    fill="none"
                                    stroke="url(#GradientColor1)"
                                    strokeWidth="20"
                                    strokeDasharray={2 * Math.PI * 70}
                                    strokeDashoffset={calculateStrokeDashoffset(timePercentage)}
                                    strokeLinecap="round"
                                    className="animated-circle"
                                />
                                <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" fontSize="24"
                                      fill="black" fontWeight="bold">
                                    {timePercentage}%
                                </text>
                                <text x="50%" y="70%" dominantBaseline="middle" textAnchor="middle" fontSize="12"
                                      fill="black">
                                    Time
                                </text>
                            </svg>
                        </div>
                        <div className="circle">
                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="160px" height="160px">
                                <defs>
                                    <linearGradient id="GradientColor2">
                                        <stop offset="0%" stopColor="#4caf50"/>
                                        <stop offset="100%" stopColor="#2196f3"/>
                                    </linearGradient>
                                </defs>
                                <circle cx="80" cy="80" r="70" fill="none" stroke="#e0e0e0" strokeWidth="20"/>
                                <circle
                                    cx="80"
                                    cy="80"
                                    r="70"
                                    fill="none"
                                    stroke="url(#GradientColor2)"
                                    strokeWidth="20"
                                    strokeDasharray={2 * Math.PI * 70}
                                    strokeDashoffset={calculateStrokeDashoffset(correctionPercentage)}
                                    strokeLinecap="round"
                                    className="animated-circle"
                                />
                                <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" fontSize="24"
                                      fill="black" fontWeight="bold">
                                    {correctionPercentage}%
                                </text>
                                <text x="50%" y="70%" dominantBaseline="middle" textAnchor="middle" fontSize="12"
                                      fill="black">
                                    Correction
                                </text>
                            </svg>
                        </div>
                        <div className="circle">
                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="160px" height="160px">
                                <defs>
                                    <linearGradient id="GradientColor3">
                                        <stop offset="0%" stopColor="#ff5722"/>
                                        <stop offset="100%" stopColor="#ffc107"/>
                                    </linearGradient>
                                </defs>
                                <circle cx="80" cy="80" r="70" fill="none" stroke="#e0e0e0" strokeWidth="20"/>
                                <circle
                                    cx="80"
                                    cy="80"
                                    r="70"
                                    fill="none"
                                    stroke="url(#GradientColor3)"
                                    strokeWidth="20"
                                    strokeDasharray={2 * Math.PI * 70}
                                    strokeDashoffset={calculateStrokeDashoffset(overallPercentage)}
                                    strokeLinecap="round"
                                    className="animated-circle"
                                />
                                <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" fontSize="24"
                                      fill="black" fontWeight="bold">
                                    {overallPercentage}%
                                </text>
                                <text x="50%" y="70%" dominantBaseline="middle" textAnchor="middle" fontSize="12"
                                      fill="black">
                                    Overall
                                </text>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
            <Footer/>
        </>
    );
}

export default SubjectCategory;